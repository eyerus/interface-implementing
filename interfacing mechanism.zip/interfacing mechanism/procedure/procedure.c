/* the code is to test procedure implementation. calling a function muptiple times.*/
#include<stdio.h>
void gradeReport(int x)
{
if (x > 90){
        printf("Your grade is Excellent.You have passed the course");
};
else if(x > 80){
        printf("Your grade is very good.You have passed the course");
};
else if(x > 70){
        printf("Your grade is good.You have passed the course");
};
else if (x > 60){
        printf("Your grade is fair.You have passed the course but need to improve");
};
else{
        printf("sorry.your grade is not good.\n");
}


int main()
{
        int a, b, c;

        printf("Type your grade in number \n");
        scanf("%d", &a);
        gradeReport(a);

        printf("Type your grade in number\n");
        scanf("%d", &b);
       gradeReport(b);

        printf("Type your grade in number\n");
        scanf("%d", &c);
        gradeReport(c);

return 0;
}